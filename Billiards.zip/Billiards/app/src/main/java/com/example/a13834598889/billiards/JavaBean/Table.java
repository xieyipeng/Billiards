package com.example.a13834598889.billiards.JavaBean;

import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobObject;

/**
 * Created by 13834598889 on 2018/4/29.
 */

public class Table extends BmobObject{
    private ShopKeeper shopKeeper;  //球桌拥有店家
    private Integer table_number;  //球桌编号
    private Boolean isReserve;  //是否已经被预定
    private Boolean isStart;  //是否已经开始计费
    private String time_start;  //开台时间
    private String time_end;   //结束计费时间
    private double money_table;  //应付太费金额

    public Table(){
        this.table_number=0;
        this.isReserve=false;
        this.isStart=false;
        this.time_start="00:00";
        this.time_end="00:00";
    }

    public ShopKeeper getShopKeeper() {
        return shopKeeper;
    }

    public void setShopKeeper(ShopKeeper shopKeeper) {
        this.shopKeeper = shopKeeper;
    }

    public Integer getTable_number() {
        return table_number;
    }

    public void setTable_number(Integer table_number) {
        this.table_number = table_number;
    }

    public Boolean getReserve() {
        return isReserve;
    }

    public void setReserve(Boolean reserve) {
        isReserve = reserve;
    }

    public Boolean getStart() {
        return isStart;
    }

    public void setStart(Boolean start) {
        isStart = start;
    }

    public String getTime_start() {
        return time_start;
    }

    public void setTime_start(String time_start) {
        this.time_start = time_start;
    }

    public String getTime_end() {
        return time_end;
    }

    public void setTime_end(String time_end) {
        this.time_end = time_end;
    }

    public double getMoney_table() {
        return money_table;
    }

    public void setMoney_table(double money_table) {
        this.money_table = money_table;
    }
}
