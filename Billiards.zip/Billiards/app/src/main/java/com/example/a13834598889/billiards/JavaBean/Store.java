package com.example.a13834598889.billiards.JavaBean;

import cn.bmob.v3.BmobObject;

/**
 * Created by 13834598889 on 2018/4/29.
 */

public class Store extends BmobObject {
    private ShopKeeper shopKeeper;  //零食小站拥有店面
}
