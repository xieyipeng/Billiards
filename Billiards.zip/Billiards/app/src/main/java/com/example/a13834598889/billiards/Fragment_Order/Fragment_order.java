package com.example.a13834598889.billiards.Fragment_Order;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.baidu.mapapi.SDKInitializer;
import com.baidu.mapapi.map.MapView;
import com.bumptech.glide.Glide;
import com.example.a13834598889.billiards.OtherActivity.Billards;
import com.example.a13834598889.billiards.R;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by 13834598889 on 2018/4/29.
 */

public class Fragment_order extends Fragment implements View.OnClickListener{
    private CircleImageView circleImageView1;
    private MapView mapView =null;
    private Button button_yuyuedaqiu;
    private Button button_xitongtuijian;

    public static Fragment_order newInstance(){
        Fragment_order fragment_order = new Fragment_order();
        return fragment_order;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_order,container,false);
        SDKInitializer.initialize(getActivity().getApplicationContext());
        mapView=(MapView)view.findViewById(R.id.mapView);
        button_yuyuedaqiu = (Button)view.findViewById(R.id.button_fragment_order_yuyuedaqiu);
        button_xitongtuijian = (Button) view.findViewById(R.id.button_fragment_order_xitongtuiijian);
        button_yuyuedaqiu.setOnClickListener(this);
        button_xitongtuijian.setOnClickListener(this);
        circleImageView1 = (CircleImageView)view.findViewById(R.id.circleImageView_mine1);
        Glide.with(getActivity())
                .load(R.drawable.test_touxiang)
                .into(circleImageView1);
        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.button_fragment_order_yuyuedaqiu:
                Intent intent = Billards.newInstance(getActivity(),1);
                startActivity(intent);
                break;
            case R.id.button_fragment_order_xitongtuiijian:
                Toast.makeText(getActivity(),"还没实现呢",Toast.LENGTH_SHORT).show();
                break;
                default:
                    break;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        mapView.onPause();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mapView.onDestroy();
    }
}
