package com.example.a13834598889.billiards.JavaBean;

import cn.bmob.v3.BmobObject;

/**
 * Created by 13834598889 on 2018/4/29.
 */

public class Order extends BmobObject {
    private ShopKeeper shopKeeper;   //订单接受店面
    private Customer customer;   //订单发起者
    private String time;   //发起订单时间
    private Integer tableNumber;   //发送订单的台桌号
    private String commodity;   //商品
    private String payment_method;  //支付方式
    private Double isDeal;  //是否已经处理

    public ShopKeeper getShopKeeper() {
        return shopKeeper;
    }

    public void setShopKeeper(ShopKeeper shopKeeper) {
        this.shopKeeper = shopKeeper;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Integer getTableNumber() {
        return tableNumber;
    }

    public void setTableNumber(Integer tableNumber) {
        this.tableNumber = tableNumber;
    }

    public String getCommodity() {
        return commodity;
    }

    public void setCommodity(String commodity) {
        this.commodity = commodity;
    }

    public String getPayment_method() {
        return payment_method;
    }

    public void setPayment_method(String payment_method) {
        this.payment_method = payment_method;
    }

    public Double getIsDeal() {
        return isDeal;
    }

    public void setIsDeal(Double isDeal) {
        this.isDeal = isDeal;
    }
}
