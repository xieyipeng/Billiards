package com.example.a13834598889.billiards.JavaBean;

import cn.bmob.v3.BmobObject;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.datatype.BmobFile;

/**
 * Created by 13834598889 on 2018/4/29.
 */

public class User extends BmobUser{
    private int age;  //年龄
    private String id_Name;  //昵称
    private Boolean isShopKeeper;  //是否是店家
    private String signature;  //个性签名
    private BmobFile file_head_sculpture;  //头像

    public BmobFile getFile_head_sculpture() {
        return file_head_sculpture;
    }

    public void setFile_head_sculpture(BmobFile file_head_sculpture) {
        this.file_head_sculpture = file_head_sculpture;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getId_Name() {
        return id_Name;
    }

    public void setId_Name(String id_Name) {
        this.id_Name = id_Name;
    }

    public Boolean getShopKeeper() {
        return isShopKeeper;
    }

    public void setShopKeeper(Boolean shopKeeper) {
        isShopKeeper = shopKeeper;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }
}
