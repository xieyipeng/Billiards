package com.example.a13834598889.billiards.JavaBean;

/**
 * Created by 13834598889 on 2018/4/29.
 */

public class Customer extends User{
}
