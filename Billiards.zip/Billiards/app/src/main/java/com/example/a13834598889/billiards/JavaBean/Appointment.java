package com.example.a13834598889.billiards.JavaBean;

import cn.bmob.v3.BmobObject;

/**
 * Created by 13834598889 on 2018/4/29.
 */

public class Appointment extends BmobObject{
    private ShopKeeper shopKeeper;  //预约店面
    private Customer customer;  //预约发起人
    private String time_order;  //预约发起时间
    private String time_start;  //预约到店时间
    private Double appointment_money;  //预约应付款金额

    public ShopKeeper getShopKeeper() {
        return shopKeeper;
    }

    public void setShopKeeper(ShopKeeper shopKeeper) {
        this.shopKeeper = shopKeeper;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String getTime_order() {
        return time_order;
    }

    public void setTime_order(String time_order) {
        this.time_order = time_order;
    }

    public String getTime_start() {
        return time_start;
    }

    public void setTime_start(String time_start) {
        this.time_start = time_start;
    }

    public Double getAppointment_money() {
        return appointment_money;
    }

    public void setAppointment_money(Double appointment_money) {
        appointment_money = appointment_money;
    }
}
