package com.example.a13834598889.billiards.JavaBean;

import android.content.Intent;

import cn.bmob.v3.datatype.BmobFile;

/**
 * Created by 13834598889 on 2018/4/29.
 */

public class ShopKeeper extends User{
    private Double money_all;  //交易总金额
    private Double money_month;  //月交易金额
    private Double money_year;  //年交易金额
    private Double score_enviroment;  //环境评分
    private Double score_service;  //服务评分
    private Double score_average;  //综合评分
    private Integer advertisment_amount;  //广告图片数
    private BmobFile file_advertisement_1;  //广告图片1
    private BmobFile file_advertisement_2;  //广告图片2
    private BmobFile file_advertisement_3;  //广告图片3
    private BmobFile file_enviroment_picture_1;  //实体环境图片1
    private BmobFile file_enviroment_picture_2;  //实体环境图片2
    private Integer grant_ball_all;  //发放的总球币数量
    private String grant_ball_password;  //发放球币的密码
    private Integer table_number;  //球桌数量

    public Double getMoney_all() {
        return money_all;
    }

    public void setMoney_all(Double money_all) {
        this.money_all = money_all;
    }

    public Double getMoney_month() {
        return money_month;
    }

    public void setMoney_month(Double money_month) {
        this.money_month = money_month;
    }

    public Double getMoney_year() {
        return money_year;
    }

    public void setMoney_year(Double money_year) {
        this.money_year = money_year;
    }

    public Double getScore_enviroment() {
        return score_enviroment;
    }

    public void setScore_enviroment(Double score_enviroment) {
        this.score_enviroment = score_enviroment;
    }

    public Double getScore_service() {
        return score_service;
    }

    public void setScore_service(Double score_service) {
        this.score_service = score_service;
    }

    public Double getScore_average() {
        return score_average;
    }

    public void setScore_average(Double score_average) {
        this.score_average = score_average;
    }

    public Integer getAdvertisment_amount() {
        return advertisment_amount;
    }

    public void setAdvertisment_amount(Integer advertisment_amount) {
        this.advertisment_amount = advertisment_amount;
    }

    public BmobFile getFile_advertisement_1() {
        return file_advertisement_1;
    }

    public void setFile_advertisement_1(BmobFile file_advertisement_1) {
        this.file_advertisement_1 = file_advertisement_1;
    }

    public BmobFile getFile_advertisement_2() {
        return file_advertisement_2;
    }

    public void setFile_advertisement_2(BmobFile file_advertisement_2) {
        this.file_advertisement_2 = file_advertisement_2;
    }

    public BmobFile getFile_advertisement_3() {
        return file_advertisement_3;
    }

    public void setFile_advertisement_3(BmobFile file_advertisement_3) {
        this.file_advertisement_3 = file_advertisement_3;
    }

    public BmobFile getFile_enviroment_picture_1() {
        return file_enviroment_picture_1;
    }

    public void setFile_enviroment_picture_1(BmobFile file_enviroment_picture_1) {
        this.file_enviroment_picture_1 = file_enviroment_picture_1;
    }

    public BmobFile getFile_enviroment_picture_2() {
        return file_enviroment_picture_2;
    }

    public void setFile_enviroment_picture_2(BmobFile file_enviroment_picture_2) {
        this.file_enviroment_picture_2 = file_enviroment_picture_2;
    }

    public Integer getGrant_ball_all() {
        return grant_ball_all;
    }

    public void setGrant_ball_all(Integer grant_ball_all) {
        this.grant_ball_all = grant_ball_all;
    }

    public String getGrant_ball_password() {
        return grant_ball_password;
    }

    public void setGrant_ball_password(String grant_ball_password) {
        this.grant_ball_password = grant_ball_password;
    }

    public Integer getTable_number() {
        return table_number;
    }

    public void setTable_number(Integer table_number) {
        this.table_number = table_number;
    }
}
